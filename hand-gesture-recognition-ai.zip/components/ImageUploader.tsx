
import React, { useState, useCallback, DragEvent, ChangeEvent } from 'react';
import { UploadCloudIcon } from './IconComponents';

interface ImageUploaderProps {
  onImageUpload: (file: File) => void;
  imageUrl: string | null;
}

const ImageUploader: React.FC<ImageUploaderProps> = ({ onImageUpload, imageUrl }) => {
  const [isDragging, setIsDragging] = useState(false);

  const handleDragEnter = (e: DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDragOver = (e: DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = useCallback((e: DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if(file.type.startsWith('image/')){
        onImageUpload(file);
      }
    }
  }, [onImageUpload]);

  const handleFileChange = useCallback((e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
        const file = e.target.files[0];
        if(file.type.startsWith('image/')){
            onImageUpload(file);
        }
    }
  }, [onImageUpload]);

  return (
    <label
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
      className={`w-full aspect-video rounded-lg border-2 border-dashed flex items-center justify-center cursor-pointer transition-all duration-300 ease-in-out relative overflow-hidden ${isDragging ? 'border-indigo-500 bg-indigo-900/30' : 'border-gray-600 hover:border-gray-500 bg-gray-900/50'}`}
    >
      <input type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
      
      {imageUrl ? (
        <>
            <img src={imageUrl} alt="Uploaded gesture" className="w-full h-full object-contain" />
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                <p className="text-white text-lg font-semibold">Change Image</p>
            </div>
        </>
      ) : (
        <div className="text-center text-gray-400 p-4">
          <UploadCloudIcon className="w-12 h-12 mx-auto mb-4" />
          <p className="font-semibold">
            <span className="text-indigo-400">Click to upload</span> or drag and drop
          </p>
          <p className="text-xs mt-1">PNG, JPG, WEBP, etc.</p>
        </div>
      )}
    </label>
  );
};

export default ImageUploader;
