
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="text-center">
      <h1 className="text-4xl sm:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-500">
        Hand Gesture Recognition AI
      </h1>
      <p className="mt-4 text-lg text-gray-300 max-w-2xl mx-auto">
        Upload an image of a hand gesture, and our AI will identify it for you. This model is trained to recognize 10 distinct gestures.
      </p>
    </header>
  );
};

export default Header;
