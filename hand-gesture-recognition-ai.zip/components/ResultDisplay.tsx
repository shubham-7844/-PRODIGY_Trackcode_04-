
import React from 'react';
import type { GestureResult } from '../types';

interface ResultDisplayProps {
  result: GestureResult;
}

const ResultDisplay: React.FC<ResultDisplayProps> = ({ result }) => {
  const confidencePercentage = (result.confidence * 100).toFixed(1);
  
  const getConfidenceColor = (confidence: number) => {
    if (confidence > 0.85) return 'bg-green-500';
    if (confidence > 0.6) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <div className="w-full text-center animate-fade-in">
      <h2 className="text-gray-400 text-sm font-medium uppercase tracking-wider">Identified Gesture</h2>
      <p className="text-4xl sm:text-5xl font-bold capitalize mt-2 text-indigo-400">{result.gesture.replace('_', ' ')}</p>
      
      <div className="w-full mt-6">
        <div className="flex justify-between items-center mb-1 text-sm text-gray-300">
          <span>Confidence Score</span>
          <span>{confidencePercentage}%</span>
        </div>
        <div className="w-full bg-gray-700 rounded-full h-2.5">
          <div 
            className={`h-2.5 rounded-full transition-all duration-500 ease-out ${getConfidenceColor(result.confidence)}`}
            style={{ width: `${confidencePercentage}%` }}
          ></div>
        </div>
      </div>

      <div className="mt-8 text-left bg-gray-800/50 p-4 rounded-lg border border-gray-700">
        <h3 className="font-semibold text-gray-200">AI Reasoning:</h3>
        <p className="mt-2 text-sm text-gray-300 italic">"{result.reasoning}"</p>
      </div>
    </div>
  );
};

export default ResultDisplay;
