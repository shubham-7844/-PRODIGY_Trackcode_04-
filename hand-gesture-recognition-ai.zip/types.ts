
export enum Gesture {
  Palm = 'palm',
  L = 'l',
  Fist = 'fist',
  FistMoved = 'fist_moved',
  Thumb = 'thumb',
  Index = 'index',
  Ok = 'ok',
  PalmMoved = 'palm_moved',
  C = 'c',
  Down = 'down'
}

export interface GestureResult {
  gesture: Gesture;
  confidence: number;
  reasoning: string;
}
