
import React, { useState, useCallback } from 'react';
import type { GestureResult } from './types';
import { classifyGesture } from './services/geminiService';
import Header from './components/Header';
import ImageUploader from './components/ImageUploader';
import ResultDisplay from './components/ResultDisplay';
import Loader from './components/Loader';
import { HandIcon, AlertTriangleIcon } from './components/IconComponents';

const App: React.FC = () => {
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [result, setResult] = useState<GestureResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleImageChange = (file: File | null) => {
    if (file) {
      setImageFile(file);
      setImageUrl(URL.createObjectURL(file));
      setResult(null);
      setError(null);
    }
  };

  const handleClassifyClick = useCallback(async () => {
    if (!imageFile) {
      setError("Please upload an image first.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      const reader = new FileReader();
      reader.readAsDataURL(imageFile);
      reader.onloadend = async () => {
        const base64data = (reader.result as string).split(',')[1];
        const mimeType = imageFile.type;
        
        const classificationResult = await classifyGesture(base64data, mimeType);
        setResult(classificationResult);
      };
      reader.onerror = () => {
          throw new Error("Failed to read the image file.");
      }
    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : "An unknown error occurred during classification.");
    } finally {
      setIsLoading(false);
    }
  }, [imageFile]);
  
  const handleReset = () => {
    setImageFile(null);
    setImageUrl(null);
    setResult(null);
    setError(null);
    setIsLoading(false);
  };


  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 flex flex-col items-center p-4 sm:p-6 lg:p-8 font-sans">
      <div className="w-full max-w-4xl mx-auto">
        <Header />
        <main className="mt-8 bg-gray-800/50 rounded-2xl shadow-2xl p-6 sm:p-8 backdrop-blur-sm border border-gray-700">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="flex flex-col items-center justify-center">
              <ImageUploader onImageUpload={handleImageChange} imageUrl={imageUrl} />
              <div className="w-full mt-6 flex space-x-4">
                  <button
                    onClick={handleClassifyClick}
                    disabled={!imageFile || isLoading}
                    className="flex-1 inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-indigo-400 disabled:cursor-not-allowed transition-colors"
                  >
                    <HandIcon className="w-5 h-5 mr-2" />
                    {isLoading ? 'Analyzing...' : 'Classify Gesture'}
                  </button>
                  {imageUrl && (
                     <button
                        onClick={handleReset}
                        className="px-6 py-3 border border-gray-600 text-base font-medium rounded-md shadow-sm text-gray-300 bg-gray-700 hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500 transition-colors"
                      >
                        Reset
                      </button>
                  )}
              </div>
            </div>
            
            <div className="flex flex-col items-center justify-center bg-gray-900/50 rounded-lg p-6 min-h-[300px] border border-gray-700">
              {isLoading && <Loader />}
              {error && (
                 <div className="text-center text-red-400 flex flex-col items-center">
                    <AlertTriangleIcon className="w-12 h-12 mb-4" />
                    <h3 className="text-lg font-semibold">An Error Occurred</h3>
                    <p className="mt-1 text-red-300">{error}</p>
                </div>
              )}
              {!isLoading && !error && result && <ResultDisplay result={result} />}
              {!isLoading && !error && !result && (
                <div className="text-center text-gray-400">
                  <p className="text-lg">Your gesture analysis will appear here.</p>
                  <p className="text-sm mt-2">Upload an image and click "Classify Gesture" to begin.</p>
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
      <footer className="text-center text-gray-500 mt-12 text-sm">
        <p>Powered by Gemini AI. For educational and demonstrative purposes only.</p>
      </footer>
    </div>
  );
};

export default App;
