
import { GoogleGenAI, Type } from "@google/genai";
import type { GestureResult } from '../types';
import { Gesture } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const gestureEnumValues = Object.values(Gesture);

const classifyGestureSchema = {
  type: Type.OBJECT,
  properties: {
    gesture: {
      type: Type.STRING,
      description: 'The name of the identified gesture from the predefined list.',
      enum: gestureEnumValues,
    },
    confidence: {
      type: Type.NUMBER,
      description: 'A confidence score between 0.0 and 1.0 representing the certainty of the classification.'
    },
    reasoning: {
      type: Type.STRING,
      description: 'A brief explanation for why the gesture was classified as such, based on visual cues like finger positions.'
    }
  },
  required: ['gesture', 'confidence', 'reasoning']
};

export const classifyGesture = async (base64ImageData: string, mimeType: string): Promise<GestureResult> => {
  try {
    const imagePart = {
      inlineData: {
        data: base64ImageData,
        mimeType: mimeType,
      },
    };

    const textPart = {
        text: `Analyze the provided image and identify the hand gesture. Classify it into one of the following categories: ${gestureEnumValues.join(', ')}. Provide your classification in the specified JSON format.`
    };
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: { parts: [imagePart, textPart] },
      config: {
        responseMimeType: "application/json",
        responseSchema: classifyGestureSchema,
        systemInstruction: "You are an expert in computer vision, specifically trained on the LeapGestRecog dataset for hand gesture recognition. Your task is to accurately classify a given hand gesture image into one of the 10 predefined categories. You must only return the classification in the requested JSON format.",
      },
    });

    const jsonText = response.text.trim();
    const parsedResult = JSON.parse(jsonText);

    // Validate the parsed result against the expected type
    if (
      gestureEnumValues.includes(parsedResult.gesture) &&
      typeof parsedResult.confidence === 'number' &&
      typeof parsedResult.reasoning === 'string'
    ) {
      return parsedResult as GestureResult;
    } else {
      throw new Error("API returned an invalid data structure.");
    }

  } catch (error) {
    console.error("Error classifying gesture:", error);
    if (error instanceof Error) {
        throw new Error(`Failed to classify gesture: ${error.message}`);
    }
    throw new Error("An unknown error occurred while communicating with the AI service.");
  }
};
